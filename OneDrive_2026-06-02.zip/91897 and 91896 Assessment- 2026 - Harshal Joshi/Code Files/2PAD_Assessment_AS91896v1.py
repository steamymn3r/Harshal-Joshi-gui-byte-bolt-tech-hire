import tkinter as tk
import datetime

root = tk.Tk()
root.title("Byte & Bolt Tech Hire (Home Page)")
root.geometry("500x500")
root.configure(bg="#e8e2c8")

""" DECLARE LIST OF ITEMS, PRICES, AND MAIN FUNCTIONS. Prices are going to be calculated on a 10% day to day basis,  
meaning the price of the hired quantity will increase day by day by 10%. E.g. the ACC 1 Keyboard has a renting 
price of $10, which means per day rented, the cost price will increase by 10%. If rented for a whole 7 days,
the rent price will be $17, as 10 * 10% is $1 and 1 * 7 is 7, 7+10 = 17."""

filename = "savefile.txt"
item_list = [
    
             # SET 1
             ["ACC 1 Keyboard", 20],
             ["ACC 1 Mouse", 15],
             ["Execute PC", 60],
             ["ARD4T 672a Laptop", 32],
             ["33Gi Headset", 17],
             # SET 2
             ["ACT 2 Keyboard", 25],
             ["ACT 2 Mouse", 25],
             ["Muscle PC", 70],
             ["TR4G0N 884b Laptop", 38],
             ["36I8 Headset", 27],
             # SET 3
             ["ANe 3 Keyboard", 15],
             ["ANe 3 Mouse", 10],
             ["Bright PC", 45],
             ["CRYPT 438c Laptop", 26],
             ["33rT Headset", 10],
             # SET 4
             ["ARf 4 Keyboard", 22],
             ["ARf 4 Mouse", 17],
             ["Torrential PC", 65],
             ["TAB1TH 553d Laptop", 35],
             ["25yR Headset", 22]
             ]

# Main menu. This acts as a central hub between different functions in the program, such as new order to return order, etc
#def main_menu():

# Return order. This function will allow the user to return their order.
#def return_order():


# New order. This function will allow the user to place a new order.
#def new_order():



# Show order. This function will allow the user to view all orders, completed and current. This will also allow the user to delete or edit the orders.
#def show_order():

root.mainloop()